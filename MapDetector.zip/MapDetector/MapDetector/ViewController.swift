//
//  ViewController.swift
//  MapDetector
//
//  Created by OSU App Center on 9/24/22.
//

import UIKit
import Alamofire
import MapKit
import CoreLocation

class ViewController: UIViewController, MKMapViewDelegate {
    
    @IBOutlet weak var map: MKMapView!
    
    var userlocations = [UserLocation](){
        didSet{
            
        }
    }
    
    var userIds = [String]()
    
    var assignedLocations = [Int]()
    
    let locations:[CLLocationCoordinate2D] = [
        CLLocationCoordinate2D(latitude: 36.1219132315, longitude: -97.070689347826),
        CLLocationCoordinate2D(latitude: 36.12309852920, longitude: -97.07242847826),
        CLLocationCoordinate2D(latitude: 36.1259168317042, longitude: -97.072243695652),
        CLLocationCoordinate2D(latitude: 36.1213688666711, longitude: -97.0684067391304),
        CLLocationCoordinate2D(latitude: 36.12898963189208, longitude: -97.071319782608),
        CLLocationCoordinate2D(latitude: 36.123871158027, longitude: -97.0664610869565),
        CLLocationCoordinate2D(latitude: 36.11938453682684, longitude: -97.07153717391304),
        CLLocationCoordinate2D(latitude: 36.11620599248779, longitude: -97.07031978260869),
        CLLocationCoordinate2D(latitude: 36.12035036735190, longitude: -97.0706023913043),
        CLLocationCoordinate2D(latitude: 36.124055534235, longitude:  -97.0708523913043),
        
        CLLocationCoordinate2D(latitude: 36.1268211253936, longitude: 97.068200217391),
        CLLocationCoordinate2D(latitude: 36.12437160672808, longitude: -97.06929804347827),
        CLLocationCoordinate2D(latitude: 36.11966550693223, longitude: -97.0693850000000),
        CLLocationCoordinate2D(latitude: 36.1198235521747, longitude: -97.0668089130434),
        CLLocationCoordinate2D(latitude: 36.11907722462278, longitude: -97.065645869565),
        CLLocationCoordinate2D(latitude: 36.1269528177803, longitude: -97.065135),
        CLLocationCoordinate2D(latitude: 36.12436282695377, longitude: -97.0651567391304),
        CLLocationCoordinate2D(latitude: 36.11860308343421, longitude: -97.06687413043477),
        CLLocationCoordinate2D(latitude: 36.1197884310371, longitude: -97.0653958695652),
        CLLocationCoordinate2D(latitude: 36.1226244123037, longitude: -97.0677110869565)
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let coordinate = CLLocationCoordinate2D(latitude: 36.1237658, longitude: -97.068635)
        map.isZoomEnabled = true
        map.delegate = self
        map.setRegion(MKCoordinateRegion(center: coordinate, span: MKCoordinateSpan(latitudeDelta: 0.009, longitudeDelta: 0.009)), animated: true)
        
        fetchNotes()
    }
    
    
    func addPin(userL:UserLocation){
        
       
            let ant = MKPointAnnotation()
            ant.title = userL.user.userId ?? "N/A"
        ant.subtitle = (userL.user.speed ?? "0") + " mph"
            ant.coordinate = userL.location
            map.addAnnotation(ant)
        
    }
    
    @IBAction func refreshTapped(_ sender: Any) {
        fetchNotes()
    }
    
//    @IBAction func clearTapped(_ sender: Any) {
//
//        guard let users = users else {
//            return
//        }
//
//        for user in users{
//            if let id = user.userId{
//                deleteNote(id: id)
//            }
//        }
//
//    }
    
    func fetchNotes() {
        AF.request("http://10.227.176.4:8085/fetch").response { response in
            
            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
                print(data)
                print(utf8Text)
                do{
                    
                    let _users = try JSONDecoder().decode([User].self,from: utf8Text.data(using: .utf8)!)
                    print(_users.count)
                    
                    for user in _users{
                        
                        
                        let alreadyExist = self.userIds.contains(user.userId!)
                        
                        if !alreadyExist{
                            let i = Int.random(in: 0..<self.locations.count)
                            if !self.assignedLocations.contains(i){
                                let userL = UserLocation(user: user, location: self.locations[i])
                                self.userlocations.append(userL)
                                self.assignedLocations.append(i)
                                self.userIds.append(user.userId!)
                                self.addPin(userL: userL)
                            }
                        }
                    }
                    
                }catch let jsonErr {
                    print(jsonErr)
                }
                
            }
        }
    }
    
//    func deleteNote(id: String) {
//        AF.request("http://10.227.114.179:8085/delete", method: .post,  encoding: URLEncoding.httpBody, headers: ["id": id]).responseJSON { (response) in
//        }
//    }
//
    
//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//        for touch in touches {
//                let touchPoint = touch.location(in: self.map)
//                let location = self.map.convert(touchPoint, toCoordinateFrom: self.map)
//                print ("\(location.latitude), \(location.longitude)")
//            }
//    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        guard !(annotation is MKUserLocation) else {return nil}
        
        var annotationView = map.dequeueReusableAnnotationView(withIdentifier: "custom")
        
        if annotationView == nil{
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "custom")
            annotationView?.canShowCallout = true
            //annotationView?.rightCalloutAccessoryView
        }else{
            annotationView?.annotation = annotation
        }
        annotationView?.image = UIImage(named: "car")
        
        return annotationView
    }
    
    
}

