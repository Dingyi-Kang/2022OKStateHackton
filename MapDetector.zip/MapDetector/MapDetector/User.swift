//
//  User.swift
//  MapDetector
//
//  Created by OSU App Center on 9/24/22.
//

import Foundation
import CoreLocation

struct User:Decodable {
    
    var userId:String?
    var speed:String?
}


struct UserLocation{
    
    let user:User
    
    let location:CLLocationCoordinate2D
    
}
